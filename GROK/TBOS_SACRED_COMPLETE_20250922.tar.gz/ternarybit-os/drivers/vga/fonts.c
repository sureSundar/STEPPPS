// WINDSURF: Placeholder for VGA font data (graphics mode later)
// Keeping file to match structure; implement when graphics mode is added.
