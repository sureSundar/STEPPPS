// WINDSURF: Minimal boot test placeholder
#include <stdio.h>
int main(void){
    printf("[TEST] test_boot: OK (placeholder)\n");
    return 0;
}
