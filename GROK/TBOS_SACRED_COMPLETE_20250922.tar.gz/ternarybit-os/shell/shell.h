#ifndef TBOS_SHELL_H
#define TBOS_SHELL_H

#include <stdint.h>

// WINDSURF: Minimal shell interface
void shell_init(void);
void shell_loop(void);

#endif // TBOS_SHELL_H
